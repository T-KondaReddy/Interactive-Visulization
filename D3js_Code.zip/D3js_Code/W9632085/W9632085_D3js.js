$(function () {
    $("#nav-placeholder").load("../main/index.html");
});
drawBarandSelect("USD.csv"); //calling func for 1st time
d3.select("#currency").on("change", (i, d) => {
    //currency files change event
    let currencycsv = document.getElementById("currency").value; //getting selected value

    drawBarandSelect(currencycsv); //drawing bar and select options function
});
function drawBarandSelect(csv) {
    switch (csv) {
        case 'USD.csv':
            Label = 'USD: Unsafe Sanitation';
            break;
        case 'UWD.csv':
            Label = 'UWD: Unsafe Drinking Water';
            break;
    }
    document.getElementById("Label").innerHTML = "" + Label;
    d3.csv(csv).then(function (data) {
        //loading csv file
        let countryOptions = [];

        data.forEach((d, i) => {
            //getting all countries names
            countryOptions.push(d.country);
            Object.keys(d).forEach((c, j) => {
                if (c !== "country") {
                    d[c] = +d[c]; //converting data from string to number
                }
            });
        });

        d3.select("#country") //adding all countries name options in select
            .selectAll("option")
            .data(countryOptions)
            .enter()
            .append("option")
            .text(function (d) {
                return d;
            })
            .attr("value", function (d) {
                return d;
            });

        let barsData = [];

        data.forEach((d) => {
            //converting raw data to processed one
            if (d.country == document.getElementById("country").value) {
                Object.keys(d).forEach((b) => {
                    if (b != "country")
                        barsData.push({
                            x: b,
                            y: d[b],
                            country: d.country,
                        });
                });
            }
        });

        drawChart(barsData); //calling drawing function
        d3.select("#country").on("change", function (d) {
            //adding change event on country dropdown
            barsData = [];
            data.forEach((d) => {
                //filtering and processing data on the basis of selected country
                if (d.country == document.getElementById("country").value) {
                    Object.keys(d).forEach((b) => {
                        if (b != "country")
                            barsData.push({
                                x: b,
                                y: d[b],
                                country: d.country,
                            });
                    });
                }
            });
            drawChart(barsData); //calling drawing function
        });

        function drawChart(barsdata) {
            d3.select("svg").remove(); //removing old svg
            let config = {
                height: 480,
                width: 900,
                margin: {
                    top: 10,
                    left: 30,
                    right: 40,
                    bottom: 50,
                },
            };

            let svg = d3 //adding svg
                .select("#countryBarChart")
                .append("svg")
                .attr(
                    "width",
                    config.width + config.margin.left + config.margin.right
                )
                .attr(
                    "height",
                    config.height + config.margin.top + config.margin.bottom
                )
                .attr(
                    "transform",
                    `translate(${config.margin.left},${config.margin.top})`
                );

            let tooltip = d3.select("#countryBarChartTooltip");

            let yScale = d3 //making y axis
                .scaleLinear()
                .domain([0,
                    d3.max(barsdata, function (d) {
                        return d.y;
                    })
                ])
                .range([config.height, config.margin.top]). nice();
                xScale = d3 //making x axis
                    .scaleBand()
                    .domain(
                        d3.map(barsdata, function (d) {
                            return d.x;
                        })
                    )
                    .range([
                        config.margin.left + config.margin.right,
                        config.width - config.margin.right,
                    ])
                    .padding(0.3);

            const xAxis = d3.axisBottom(xScale);

            const yAxis = d3.axisLeft(yScale);

            axisX = svg //appending x axis
                .append("g")
                .attr("class", "axis x-axis")
                .attr("transform", `translate(0, ${config.height})`)
                .call(xAxis);

            axisX
                .append("text")
                .text("Years")
                .attr('class', '.text')
                .attr("y", config.height / 30 + 30)
                .attr("x", config.width / 2)
                .attr("transform", "translate (0, 0)rotate(0)")
                .style("fill", "black")
                .attr("font-size", 12)
                .attr("text-anchor", "middle");

            axisY = svg //appending y axis
                .append("g")
                .attr("class", "axis y-axis")
                .attr("transform", `translate(${+config.margin.left * 2.4}, 0)`)
                .call(yAxis);


            axisY
                .append("text")
                .text("Proportions")
                .attr('class', '.text')
                .attr("y", config.height / 2.5)
                .attr("x", config.margin.left / 10)
                .attr("transform", "translate (-230, 230)rotate(270)")
                .style("fill", "black")
                .attr("font-size", 14)
                .attr("text-anchor", "middle");

            const bars = svg //bars drawing function
                .selectAll(".bar")
                .data(barsdata)
                .enter()
                .append("rect")
                .classed("bar", true)
                .attr("class", "bars")
                .style("fill", "transparent")
                .attr("x", (d, i) => xScale(d.x))
                .attr(
                    "y",
                    yScale(
                        d3.min(data, function (d) {
                            return d.y;
                        })
                    )
                )
                .attr("width", xScale.bandwidth())
                .attr("height", 0); //height 0 at start for animation

            bars //bars animation
                .transition()
                .style("fill", (d, i) => {
                    return "#4284f3";
                })
                .duration(201) //total animation duration
                .delay((d, i) => (i * 201) / 5) //delay for each bar
                .attr("x", (d, i) => xScale(d.x)) //calculate x position of bar on the basis of x axis
                .attr("y", (d, i) => yScale(d.y)) //calculate y position of bar on the basis of y axis
                .attr("width", xScale.bandwidth()) //width of each bar using inbuilt d3 bandwidth function
                .attr("height", (d, i) => config.height - yScale(d.y)); //height of bar on the basis of value

            bars
                .on("mouseover", function (i, d) {
                    tooltip.transition().duration(300).style("opacity", 1); //adding tooltip
                    tooltip //adding values of tooltip
                        .html(
                            `<span style="font-size:12px;font-weight:bold">Year: ${d.x}<br></span><span style="font-size:12px;font-weight:bold">Value: ${d.y}<br></span><span style="font-size:12px;font-weight:bold">Country: ${d.country}<br></span>`
                        )
                        .style("visibility", "visible") //adding values on tooltip
                        .style("left", event.pageX  +50+ "px") //getting x value of cursor
                        .style("top", event.pageY +20+ "px"); //getting y value of cursor
                    d3.select(this).style("fill", "yellow");
                })
                .on("mouseleave", function (d) {
                    tooltip
                        .style("visibility", "none")
                        .transition()
                        .duration(301)
                        .style("opacity", 0);
                    d3.select(this).style("fill", "#4284f3");
                });
        }
    });
}