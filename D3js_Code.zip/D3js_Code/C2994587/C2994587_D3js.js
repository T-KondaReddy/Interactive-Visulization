
$(function () {
  $("#nav-placeholder").load("../main/index.html");
});

function myFunction(ClimateFactorsValue) {
  var e = document.getElementById("selectYear");
  var year = e.value;
  update(ClimateFactorsValue, year);
};
d3.select("select")
  .on("change", function (d) {
    SelectYear = d3.select("#selectYear").node().value;
    //document.getElementById('FGA').checked = true;
    var Climate_Factors = $("input[type='radio'][name='Climate Factors']:checked").val();
    console.log(Climate_Factors);
    update(Climate_Factors, SelectYear);
  });

const margin = { top: 20, right: 50, bottom: 100, left: 100 },
  width = 800, height = 600,
  graphWidth = width - margin.left - margin.right,
  graphHeight = height - margin.top - margin.bottom;  

// Append the SVG object to the body of the page
const svg =
  d3.select("#my_dataviz")
    .append('svg')
    .attr('width', width)
    .attr('height', height)
    .append('g')
    .attr('transform', `translate(${margin.left},${margin.top})`);
function update(selectedVar, SelectYear) {
  console.log(selectedVar);
  switch (selectedVar) {
    case 'FGA_Value':
      Label = 'FGA: Fluorinated gas growth rate';
      break;
    case 'NDA_Value':
      Label = 'NDA: Nitrous oxide growth rate';
      break;
    case 'CHA_Value':
      Label = 'CHA: Methane growth rate';
      break;
    case 'CDA_Value':
      Label = 'CDA: Carbondioxide growth rate';
      break;
  }
  document.getElementById("Label").innerHTML = "" + Label;
  svg.selectAll('*').remove();
  // Initialize the Y axis
  const scaleY = d3.scaleBand()
    .range([graphHeight, 0])
    .paddingInner(0.2)
    .paddingOuter(0.2)

  const scaleX = d3.scaleLinear()
    .range([0, graphWidth]);

  // Parse the date / time
  var parseYear = d3.timeParse("%Y");

  // A function that create / update the plot for a given variable:
  d3.csv("Dataset.csv").then(buildBarChart);

  function buildBarChart(data) {
    const allYears = data.map(function (d) { return (d.Year); });
    let Years = [...new Set(allYears)];
    // Format the data
    var variables = ['NDA_Value', 'FGA_Value', 'CHA_Value', 'CDA_Value'];
    // Get dropdown element from DOM
    var dropdown = document.getElementById("selectYear");
    // Loop through the array
    for (var i = 1; i < Years.length; ++i) {
      // Append the element to the end of Array list
      if (dropdown.length <= 20) {
        dropdown[dropdown.length] = new Option(Years[i], Years[i]);
      }
    };
    console.log(SelectYear);
    data = data.filter(function (d) { return d.Year == SelectYear });

    data.forEach(function (d) {
      d.Year = parseYear(d.Year);
      for (var i = 0; i < variables.length; i++) {
        d[variables[i]] = +d[variables[i]];
      }
    });
    let tooltip = d3.select("#countryBarChartTooltip");
    const catY = data.map(function (d) { return (d.Country); });
    //console.log(catY);
    scaleY.domain(catY);
    axisY = svg.append("g")
      .attr('transform', 'translate(' + scaleX(0) + ',0)')
      .attr("class", "myYaxis")
      .call(d3.axisLeft(scaleY));

    axisY
      .append("text")
      .text("Country")
      .attr('class', '.text')
      .attr("y", height / 4)
      .attr("x", margin.left / 10)
      .attr("transform", "translate (-230, 230)rotate(270)")
      .style("fill", "black")
      .style("font-weight", "bold ")
      .attr("font-size", 14)
      .attr("text-anchor", "middle");

    scaleX.domain([d3.min(data, function (d) {
      return +d[selectedVar]
    }),
    d3.max(data, function (d) {
      return +d[selectedVar]
    })]).nice();
    axisX = svg.append("g")
      .attr("class", "myXaxis")
      .attr('transform', `translate(0, ${graphHeight})`)
      .call(d3.axisBottom(scaleX));

    axisX
      .append("text")
      .text("Proportions")
      .attr('class', '.text')
      .attr("y", height / 20)
      .attr("x", graphWidth / 2)
      .attr("transform", "translate (0, 0)rotate(0)")
      .style("fill", "black")
      .style("font-weight", "bold ")
      .attr("font-size", 12)
      .attr("text-anchor", "middle");


    svg.selectAll(".bar")
      .data(data)
      .enter().append("rect")
      .attr("class", function (d) { return "bar bar--" + (parseFloat(+d[selectedVar].toFixed(3)) < 0 ? "n" : "p"); })
      .on("mouseover", onMouseOver)
      .on("mouseout", onMouseOut)
      .transition()
      .duration(200) //total animation duration
            .delay((d, i) => (i * 200) / 5) //delay for each bar
      .ease(d3.easeExpInOut)
      .attr("x", function (d) { return scaleX(Math.min(0, +d[selectedVar])); })
      .attr("y", function (d, i) { return scaleY(catY[i]); })
      .attr("height", scaleY.bandwidth())
      .attr("width", function (d) { return (Math.abs(scaleX(+d[selectedVar]) - scaleX(0))); });

    var Varvalue;

    function onMouseOver(d, i) {
      d3.select(this).attr('class', 'highlight')
      d3.select(this)
        .transition()
        .duration(100)
        .attr("width", function (d) {
          Varvalue = parseFloat(+d[selectedVar].toFixed(3))
          return (Math.abs(scaleX(+d[selectedVar]) - scaleX(0)) + 2);
        })
        .attr("height", scaleY.bandwidth() + 2)
      tooltip.transition().duration(300).style("opacity", 1); //display tooltip
      tooltip // data in tooltip
        .html(
          `<span style="font-size:12px;font-weight:bold">Value: ${Varvalue}<br></span>
                <span style="font-size:12px;font-weight:bold">Country: ${i.Country}<br></span>`
        )
        .style("display", "block") //showing tooltip
        .style("left", event.pageX + 5 + "px") //for getting the x position of cursor
        .style("top", event.pageY + 5 + "px"); //for getting y poisiton of cursor
    };
    function onMouseOut(d, i) {
      d3.select(this).attr('class', function (d) { return "bar bar--" + (parseFloat(+d[selectedVar].toFixed(3)) < 0 ? "n" : "p"); });
      d3.select(this)
        .transition()
        .duration(400)
        .attr("width", function (d) { return (Math.abs(scaleX(+d[selectedVar]) - scaleX(0))); })
      tooltip
        .style("visibility", "none")
        .transition()
        .duration(400)
        .style("opacity", 0);
      d3.selectAll('.val')
        .remove()
    };

    svg.append("rect").attr("width", 20).attr("height", 20).attr("y", 530).attr("x", 100).style("fill", "darkorange");
    svg.append("rect").attr("width", 20).attr("height", 20).attr("y", 530).attr("x", 250).style("fill", '#4284f3');
    svg.append("text").attr("y", 540).attr("x", 130).text("Negative Values").style("font-size", "13px").attr("alignment-baseline", "middle");
    svg.append("text").attr("y", 540).attr("x", 280).text("Postivie Values").style("font-size", "13px").attr("alignment-baseline", "middle");
    svg.append("text").attr("y", 570).attr("x", 410).text("Data Source: " + "https://sedac.ciesin.columbia.edu/" + "").style("font-size", "13px");

  }
}

update('FGA_Value', '1999');
