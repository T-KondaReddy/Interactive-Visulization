$(function () {
    $("#nav-placeholder").load("../main/index.html");
});
linechart();
function cleardata(data, country, columns) {
    //processed/filtering data
    let cleaned = [];
    data.forEach((b) => {
        if (b.country.localeCompare(country) == 0) {
            columns.forEach((d) => {
                cleaned.push({
                    yvalue: parseFloat(b[d]),
                    xvalue: d,
                    country: b.country,
                });
            });
        }
    });
    return cleaned;
}
function linechart() {
    //draw line chart
    let cleaned = [];
    d3.csv("Clean_datav1.csv").then(function (data) {
        //loading csv file
        let columns = data.columns; //csv columns names
        let countries = [];
        columns.reverse(); //for removing country label from columns
        columns.pop();
        columns.reverse();

        cleaned = cleardata(data, "Australia", columns); //by default starting with Australia

        data.forEach((d) => {
            //getting all countries names
            countries.push(d["country"]);
        });

        d3.select("#countries_options") //creating options of select
            .selectAll("option")
            .data(countries) //giving countries array
            .enter()
            .append("option")
            .text(function (d) {
                return d;
            }) //text in dropdown
            .attr("value", function (d) {
                return d;
            }); //actual value of option
        lineDrawing(cleaned, data, columns); //calling drawing function
    });
}

function lineDrawing(data, datacomp, columns) {
    //data (filterdata), datacomp (all csv data), columns(columns name array)
    const margin = { top: 10, right: 30, bottom: 30, left: 60 }, //padding/margin
        width = 760 - margin.left - margin.right, //width of svg
        height = 500 - margin.top - margin.bottom; //height of svg

    const parseTime = d3.timeParse("%Y"); //for converting string year to time

    let colorsOfCountries = {
        //created colors for all the countries
        Australia: "#922B21",
        Belgium: "#CB4335",
        China: "black",
        Denmark: "#b52c3d",
        Finland: "#2471A3",
        France: "#2E86C1",
        Germany: "#17A589",
        Greece: "#138D75",
        Ireland: "#169b62",
        Italy: "#28B463",
        Japan: "#D4AC0D",
        Luxembourg: "#D68910",
        Netherlands: "#CA6F1E",
        "New Zealand": "#BA4A00",
        Norway: "#A6ACAF",
        Portugal: "darkgreen",
        Russia: "red",
        Singapore: "#707B7C",
        "South Korea": "blue",
        Spain: "#2E4053",
        Sweden: "#273746",
        Switzerland: "#884EA0",
        "United Kingdom": "#012169",
        "United States of America": "#7D3C98",
    };

    let tip = d3 //adding tooltip
        .select("#line")
        .append("div")
        .attr("id", "tip")
        .style("opacity", 0);

    // append the svg
    const svg = d3
        .select("#line")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left}, ${margin.top})`);

    const x = d3 //creating x axis
        .scaleTime()
        .domain(
            d3.extent(data, function (d) {
                return parseTime(d.xvalue);
            })
        )
        .range([0, width]);

    xAxis = svg //appending x axis in svg
        .append("g")
        .attr("transform", `translate(0, ${height})`)
        .call(d3.axisBottom(x).ticks(15));

    xAxis
        .append("text")
        .text("Years")
        .attr('class', '.text')
        .attr("y", margin.bottom)
        .attr("x", margin.left * 5.5)
        .attr("transform", "translate (0, 0)rotate(0)")
        .style("fill", "black")
        .style("font-weight", "bold ")
        .attr("font-size", 12)
        .attr("text-anchor", "middle");

    // creating y axis
    const y = d3
        .scaleLinear()
        .domain([
            0,
            d3.max(data, function (d) {
                return d.yvalue;
            }) + 11,
        ])
        .range([height, 0]);

    let yAxis = svg.append("g").call(d3.axisLeft(y)); //adding y axis

    yAxis
        .append("text")
        .text("Age-standardized DALYs/100k people")
        .attr('class', '.text')
        .attr("y", height / 2.5)
        .attr("x", margin.left / 5)
        .attr("transform", "translate (-230, 230)rotate(270)")
        .style("fill", "black")
        .style("font-weight", "bold ")
        .attr("font-size", 14)
        .attr("text-anchor", "middle");

    d3.select("#countries_options").on("change", function (d) {
        //adding on change event
        let value = document.getElementById("countries_options").value; //getting new value of dropdown
        let filterdata = cleardata(datacomp, value, columns); //getting processed data
        update(filterdata); //updating line chart
    });

    const line = svg //creating
        .append("g")
        .append("path")
        .datum(data) //adding data
        .attr(
            //line creating function
            "d",
            d3
                .line()
                .x(function (d) {
                    return x(parseTime(d.xvalue));
                })
                .y(function (d) {
                    return y(d.yvalue);
                })
        )
        .attr("class", "path") //for mouseover class
        .attr("stroke", colorsOfCountries[data[0].country]) //line color on the basis of country name from above object
        .style("stroke-width", 4) //line width
        .style("fill", "none");
    const circles = svg //adding cricles
        .append("g")
        .selectAll("circles")
        .data(data)
        .enter()
        .append("circle")
        .attr("class", "dots")
        .attr("cx", (d) => x(parseTime(d.xvalue))) //x position of circle
        .attr("cy", (d) => y(d.yvalue)) //y position of circle
        .style("r", 5)
        .style("fill", function (d) {
            return colorsOfCountries[d.country]; //circle color
        })
        .on("mouseover", function (i, d) {
            //mouseover event
            d3.select(".path").attr("stroke", "steelblue"); //changing line color
            d3.selectAll(".dots").style("fill", "steelblue"); //changing circles colors
            tip.transition().duration(300).style("opacity", 1); //display tooltip
            tip // values showing in tooltip
                .html(
                    `<span style="font-size:12px;font-weight:bold">Country: ${d.country
                    }<br></span><span style="font-size:12px;font-weight:bold">${d.xvalue
                    }: ${Math.ceil(d.yvalue)}`
                )
                .style("display", "block") //showing tooltip
                .style("left", event.pageX + 15 + "px") //for getting the x position of cursor
                .style("top", event.pageY + "px"); //for getting y poisiton of cursor
        })
        .on("mouseout", function (i, d) {
            d3.select(".path").attr("stroke", colorsOfCountries[d.country]); //changing path color back
            d3.selectAll(".dots").style("fill", colorsOfCountries[d.country]); //changing circles color back
            tip //hiding tooltip
                .style("display", "none")
                .transition()
                .duration(250)
                .style("opacity", 0);
        });

    function update(dataFilter) {
        y.domain([
            //updating y domain values
            0,
            d3.max(dataFilter, function (d) {
                return d.yvalue;
            }) + 11,
        ]);

        yAxis.transition().duration(1000).call(d3.axisLeft(y)); //updating y axis with animation

        line //updating line with animation
            .datum(dataFilter)
            .transition()
            //.duration(1000)
            .duration(200) //total animation duration
            .delay((d, i) => (i * 200) / 5) //delay for each bar
            .attr(
                "d",
                d3
                    .line()
                    .x(function (d) {
                        return x(parseTime(d.xvalue));
                    })
                    .y(function (d) {
                        return y(d.yvalue);
                    })
            )
            .attr("stroke", function (d) {
                return colorsOfCountries[dataFilter[0].country];
            });

        svg //updating circles positions with animation
            .selectAll(".dots")
            .data(dataFilter)
            .transition()
            //.duration(1000)
            .duration(200) //total animation duration
            .delay((d, i) => (i * 200) / 5) //delay for each bar
            .attr("cx", function (d) {
                return x(parseTime(d.xvalue));
            })
            .attr("cy", function (d) {
                return y(d.yvalue);
            })
            .style("fill", function (d) {
                return colorsOfCountries[dataFilter[0].country];
            });
    }
}