$(function () {
    $("#nav-placeholder").load("../main/index.html");
});
var margin = 40; //padding
(width = 1160 - margin * 2), (height = 600 - margin * 2);

// append the svg to the body
var svg = d3
    .select("body")
    .append("svg")
    .attr("width", width-300)
    .attr("height", height + 80)
    .append("g")
    .attr("transform", "translate(" + -140 + "," + 40 + ")");

var tooltip = d3.select("#tooltip"); //getting tooltip div
// loading csv
d3.csv("slope chart.csv").then(function (csv) {
    let countries = [];
    csv.forEach((data) => {
        countries.push(data.country); //for getting all countries names
        data["2019"] = parseFloat(data["2019"]); //convertint string to number
        data["2015"] = parseFloat(data["2015"]);
        data["2010"] = parseFloat(data["2010"]);
        data["2010"] = parseFloat(data["2010"]);
    });

    var color = d3 //creating color scheme
        .scaleOrdinal()
        .domain(countries)
        .range(d3.schemeCategory10);

    dimensions = ["2005","2010","2015","2019"];

    const y = {};
    for (i in dimensions) {
        //processing
        var name = dimensions[i];
        y[name] = d3
            .scaleLog()
            .domain(
                [d3.min(csv, function (d) {
                    return +d[2019]
                }), d3.max(csv, function (d) {
                    return +d[2019]
                })])
            .range([height, 0]).nice();
    }

    //x scale for drawing line but will not visible
    x = d3.scalePoint().range([0, width]).padding(1).domain(dimensions);
    //line drawing function
    function path(d) {
        return d3.line()(
            dimensions.map(function (p) {
                return [x(p), y[p](d[p])];
            })
        );
    }

    // lines drawing
    const line = svg
        .selectAll("myPath")
        .data(csv)
        .join("path")
        .attr("stroke-width", 2.5)
        .style("opacity", 0.7);
    line
        .transition()
        .duration(500) //total animation duration
        .delay((d, i) => (i * 500) / 5) //delay for each line
        .attr("d", path)
        .style("fill", "none")
        .style("stroke", function (d) {
            //color of line
            return color(d.country);
        });

    line.on("mouseover", function (i, d) {
        //mousover event
        d3.select(this).style("opacity", 1);
        tooltip.transition().duration(300).style("opacity", 1); //display tooltip
        tooltip // data in tooltip
            .html(
                `<div style="font-size:12px;font-weight:bold">Country: ${d["country"]
                }<br>
                </div>
                <div style="font-size:12px;font-weight:bold">2005: ${Math.ceil(
                    d["2005"]
                )}</div>
    <div style="font-size:12px;font-weight:bold">2010: ${Math.ceil(
                    d["2010"]
                )}</div>
    <div style="font-size:12px;font-weight:bold">2015: ${Math.ceil(
                    d["2015"]
                )}</div>
    <div style="font-size:12px;font-weight:bold">2019: ${Math.ceil(
                    d["2019"]
                )}</div>`
            )
            .style("visibility", "visible") //showing tooltip
            .style("left", event.pageX + 15 + "px") //for getting the x position of cursor
            .style("top", event.pageY + "px"); //for getting y poisiton of cursor
    })
        .on("mouseout", function (i, d) {
            d3.select(this).style("opacity", 0.7);;

            tooltip //hiding tooltip
                .style("visibility", "none")
                .transition()
                .duration(400)
                .style("opacity", 0);
        });
    var count = 1;
    svg //drawing three y axises
        .selectAll("myAxis")
        .data(dimensions)
        .enter()
        .append("g")
        .attr("transform", function (d) {
            return "translate(" + x(d) + ")";
        })
        .each(function (d) {
            axisY = d3.select(this).call(d3.axisLeft().scale(y[d]));

            if ((d = '2010') && (count == 1)) {
                axisY
                    .append("text")
                    .text("Proportion")
                    .attr('class', '.text')
                    .attr("y", height / 3)
                    .attr("x", margin / 2)
                    .attr("transform", "translate (-230, 230)rotate(270)")
                    .style("fill", "black")
                    .attr("font-size", 14)
                    .attr("text-anchor", "middle");
                count++
            }
        })
        .append("text") //adding title
        .style("text-anchor", "middle")
        .attr("y", 550)
        .text(function (d) {
            return d;
        })
        .style("fill", "black");
});